<?php 
$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "companyprofile";

$koneksi    = mysqli_connect('localhost', 'root', '', 'companyprofile');
if(!$koneksi){
    die("Gagal terkoneksi");
}